-- "addons\\advanced_mining_system_2\\lua\\entities\\ent_copperore\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()