-- "addons\\advanced_mining_system_2\\lua\\entities\\ent_ironingot\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()