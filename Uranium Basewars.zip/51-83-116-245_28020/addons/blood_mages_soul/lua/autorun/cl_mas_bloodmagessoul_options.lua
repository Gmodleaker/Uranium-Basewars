-- "addons\\blood_mages_soul\\lua\\autorun\\cl_mas_bloodmagessoul_options.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()