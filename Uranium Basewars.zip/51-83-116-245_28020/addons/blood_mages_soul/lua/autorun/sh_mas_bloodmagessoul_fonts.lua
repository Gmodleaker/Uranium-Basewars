-- "addons\\blood_mages_soul\\lua\\autorun\\sh_mas_bloodmagessoul_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()