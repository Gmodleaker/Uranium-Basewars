-- "addons\\blood_mages_soul\\lua\\autorun\\sv_mas_bloodmagessoul_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()