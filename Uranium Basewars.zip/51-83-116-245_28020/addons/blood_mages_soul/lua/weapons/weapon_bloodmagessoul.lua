-- "addons\\blood_mages_soul\\lua\\weapons\\weapon_bloodmagessoul.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()