-- "addons\\business_animals\\lua\\effects\\ba_cage_spawn.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()