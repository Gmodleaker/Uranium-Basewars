-- "addons\\business_animals\\lua\\entities\\ba_food\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()