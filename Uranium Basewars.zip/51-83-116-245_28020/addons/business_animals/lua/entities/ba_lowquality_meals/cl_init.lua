-- "addons\\business_animals\\lua\\entities\\ba_lowquality_meals\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()