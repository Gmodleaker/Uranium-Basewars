-- "addons\\business_animals\\lua\\entities\\ba_medquality_meals\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()