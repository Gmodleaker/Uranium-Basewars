-- "addons\\business_animals\\lua\\entities\\ba_product\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()