-- "addons\\business_animals\\lua\\entities\\ba_topquality_meals\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()