-- "addons\\business_animals\\lua\\entities\\ba_water\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()