-- "addons\\ch_bitminers\\lua\\autorun\\ch_bitminers_initialize.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()