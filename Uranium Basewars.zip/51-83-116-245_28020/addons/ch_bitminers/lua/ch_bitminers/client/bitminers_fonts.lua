-- "addons\\ch_bitminers\\lua\\ch_bitminers\\client\\bitminers_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()