-- "addons\\ch_bitminers\\lua\\ch_bitminers\\client\\bitminers_ui_crypto_integration.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()