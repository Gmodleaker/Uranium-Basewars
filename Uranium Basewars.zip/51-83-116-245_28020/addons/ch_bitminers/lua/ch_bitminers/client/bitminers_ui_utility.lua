-- "addons\\ch_bitminers\\lua\\ch_bitminers\\client\\bitminers_ui_utility.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()