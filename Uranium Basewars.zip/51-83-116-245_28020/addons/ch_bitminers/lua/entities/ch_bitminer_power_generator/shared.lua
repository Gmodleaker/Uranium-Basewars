-- "addons\\ch_bitminers\\lua\\entities\\ch_bitminer_power_generator\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()