-- "addons\\ch_bitminers\\lua\\entities\\ch_bitminer_power_generator_fuel_medium\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()