-- "addons\\ch_bitminers\\lua\\entities\\ch_bitminer_power_rtg\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()