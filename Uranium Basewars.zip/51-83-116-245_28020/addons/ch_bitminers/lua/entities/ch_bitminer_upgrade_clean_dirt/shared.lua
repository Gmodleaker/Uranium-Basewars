-- "addons\\ch_bitminers\\lua\\entities\\ch_bitminer_upgrade_clean_dirt\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()