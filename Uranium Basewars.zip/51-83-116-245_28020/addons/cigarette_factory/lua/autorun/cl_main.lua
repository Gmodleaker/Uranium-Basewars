-- "addons\\cigarette_factory\\lua\\autorun\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()