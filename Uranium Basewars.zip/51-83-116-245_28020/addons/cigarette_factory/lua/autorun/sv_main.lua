-- "addons\\cigarette_factory\\lua\\autorun\\sv_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()