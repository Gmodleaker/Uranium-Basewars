-- "addons\\cigarette_factory\\lua\\cf_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()