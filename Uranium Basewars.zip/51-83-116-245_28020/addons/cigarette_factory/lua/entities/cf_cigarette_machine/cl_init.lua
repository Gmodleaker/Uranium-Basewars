-- "addons\\cigarette_factory\\lua\\entities\\cf_cigarette_machine\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()