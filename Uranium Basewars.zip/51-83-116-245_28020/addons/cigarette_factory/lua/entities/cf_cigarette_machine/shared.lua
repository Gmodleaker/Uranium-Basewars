-- "addons\\cigarette_factory\\lua\\entities\\cf_cigarette_machine\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()