-- "addons\\cigarette_factory\\lua\\entities\\cf_cigarette_pack\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()