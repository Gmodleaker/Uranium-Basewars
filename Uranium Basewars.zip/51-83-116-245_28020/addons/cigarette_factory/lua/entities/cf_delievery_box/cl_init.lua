-- "addons\\cigarette_factory\\lua\\entities\\cf_delievery_box\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()