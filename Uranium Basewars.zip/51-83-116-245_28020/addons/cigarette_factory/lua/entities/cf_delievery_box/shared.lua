-- "addons\\cigarette_factory\\lua\\entities\\cf_delievery_box\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()