-- "addons\\cigarette_factory\\lua\\entities\\cf_engine_upgrade\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()