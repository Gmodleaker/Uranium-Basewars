-- "addons\\cigarette_factory\\lua\\entities\\cf_export_van\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()