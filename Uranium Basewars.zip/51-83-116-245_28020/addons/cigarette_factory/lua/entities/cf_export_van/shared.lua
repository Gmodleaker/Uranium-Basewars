-- "addons\\cigarette_factory\\lua\\entities\\cf_export_van\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()