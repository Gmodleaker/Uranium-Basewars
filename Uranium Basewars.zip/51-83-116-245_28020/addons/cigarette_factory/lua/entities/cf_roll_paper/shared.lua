-- "addons\\cigarette_factory\\lua\\entities\\cf_roll_paper\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()