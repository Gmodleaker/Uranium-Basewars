-- "addons\\cigarette_factory\\lua\\entities\\cf_storage_upgrade\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()