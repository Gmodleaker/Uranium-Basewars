-- "addons\\cigarette_factory\\lua\\entities\\cf_tobacco_pack\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()