-- "addons\\cigarette_factory\\lua\\entities\\cf_tobacco_pack\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()