-- "addons\\fspectate\\lua\\autorun\\fspectate.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()