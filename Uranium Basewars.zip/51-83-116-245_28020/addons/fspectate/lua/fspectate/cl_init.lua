-- "addons\\fspectate\\lua\\fspectate\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()