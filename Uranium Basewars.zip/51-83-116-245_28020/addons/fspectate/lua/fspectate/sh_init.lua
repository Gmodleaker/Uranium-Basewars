-- "addons\\fspectate\\lua\\fspectate\\sh_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()