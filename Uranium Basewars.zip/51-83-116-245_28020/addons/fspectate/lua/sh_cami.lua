-- "addons\\fspectate\\lua\\sh_cami.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()