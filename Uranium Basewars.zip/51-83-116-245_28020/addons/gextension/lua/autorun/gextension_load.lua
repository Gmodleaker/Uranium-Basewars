-- "addons\\gextension\\lua\\autorun\\gextension_load.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()