-- "addons\\gextension\\lua\\gextension\\client\\cl_ttt.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()