-- "addons\\gextension\\lua\\gextension\\client\\cl_warnings.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()