-- "addons\\gextension\\lua\\gextension\\config\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()