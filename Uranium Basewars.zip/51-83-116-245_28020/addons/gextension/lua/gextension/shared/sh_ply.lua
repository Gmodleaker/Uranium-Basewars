-- "addons\\gextension\\lua\\gextension\\shared\\sh_ply.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()