-- "addons\\gmodadminsuite-config\\lua\\gmodadminsuite_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()