-- "addons\\gmodadminsuite-config\\lua\\gmodadminsuite_lua_functions.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()