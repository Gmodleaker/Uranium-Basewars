-- "addons\\gmodadminsuite-logging-2.4\\lua\\gmodadminsuite\\modules\\logging\\lang\\french.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()