-- "addons\\gmodadminsuite-logging-2.4\\lua\\gmodadminsuite\\modules\\logging\\sh_log_formatting.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()