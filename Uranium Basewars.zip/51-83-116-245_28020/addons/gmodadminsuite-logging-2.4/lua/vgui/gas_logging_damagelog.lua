-- "addons\\gmodadminsuite-logging-2.4\\lua\\vgui\\gas_logging_damagelog.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()