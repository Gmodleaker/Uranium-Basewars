-- "addons\\gmodadminsuite-logging-2.4\\lua\\vgui\\gas_logging_entity_display.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()