-- "addons\\gmodadminsuite-logging-2.4\\lua\\weapons\\gas_log_scanner\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()