-- "addons\\gms_aphone\\lua\\aphone\\_libs\\__header\\sh_devconfig.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()