-- "addons\\gms_aphone\\lua\\aphone\\_libs\\__header\\sh_language.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()