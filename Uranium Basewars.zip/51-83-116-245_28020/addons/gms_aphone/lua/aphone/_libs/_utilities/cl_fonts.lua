-- "addons\\gms_aphone\\lua\\aphone\\_libs\\_utilities\\cl_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()