-- "addons\\gms_aphone\\lua\\aphone\\_libs\\_utilities\\cl_tdlib.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()