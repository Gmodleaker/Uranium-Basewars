-- "addons\\gms_aphone\\lua\\aphone\\_libs\\gamemodes_related\\sh_darkrp.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()