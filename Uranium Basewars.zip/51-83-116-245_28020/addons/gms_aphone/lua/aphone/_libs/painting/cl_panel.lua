-- "addons\\gms_aphone\\lua\\aphone\\_libs\\painting\\cl_panel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()