-- "addons\\gms_aphone\\lua\\aphone\\_libs\\panels\\cl_advancedphone_scroll.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()