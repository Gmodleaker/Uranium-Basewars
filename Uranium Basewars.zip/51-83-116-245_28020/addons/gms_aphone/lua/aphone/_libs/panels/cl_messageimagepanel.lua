-- "addons\\gms_aphone\\lua\\aphone\\_libs\\panels\\cl_messageimagepanel.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()