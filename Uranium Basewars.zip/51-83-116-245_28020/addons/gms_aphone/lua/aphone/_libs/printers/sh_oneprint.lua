-- "addons\\gms_aphone\\lua\\aphone\\_libs\\printers\\sh_oneprint.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()