-- "addons\\gms_aphone\\lua\\aphone\\apps\\contacts\\cl_contacts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()