-- "addons\\gms_aphone\\lua\\aphone\\apps\\gallery\\cl_main.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()