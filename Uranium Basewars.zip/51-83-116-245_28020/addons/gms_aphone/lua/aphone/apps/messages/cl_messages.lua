-- "addons\\gms_aphone\\lua\\aphone\\apps\\messages\\cl_messages.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()