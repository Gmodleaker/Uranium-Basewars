-- "addons\\gms_aphone\\lua\\aphone\\languages\\french.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()