-- "addons\\gms_aphone\\lua\\aphone\\sh_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()