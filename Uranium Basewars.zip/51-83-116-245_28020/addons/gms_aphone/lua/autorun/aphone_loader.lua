-- "addons\\gms_aphone\\lua\\autorun\\aphone_loader.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()