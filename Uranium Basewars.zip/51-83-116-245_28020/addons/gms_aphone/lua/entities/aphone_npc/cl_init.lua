-- "addons\\gms_aphone\\lua\\entities\\aphone_npc\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()