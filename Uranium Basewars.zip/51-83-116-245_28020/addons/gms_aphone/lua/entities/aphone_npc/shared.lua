-- "addons\\gms_aphone\\lua\\entities\\aphone_npc\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()