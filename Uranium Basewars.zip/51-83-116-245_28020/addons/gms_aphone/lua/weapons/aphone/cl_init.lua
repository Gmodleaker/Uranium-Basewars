-- "addons\\gms_aphone\\lua\\weapons\\aphone\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()