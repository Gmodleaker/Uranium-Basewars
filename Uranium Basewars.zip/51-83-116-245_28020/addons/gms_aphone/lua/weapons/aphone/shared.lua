-- "addons\\gms_aphone\\lua\\weapons\\aphone\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()