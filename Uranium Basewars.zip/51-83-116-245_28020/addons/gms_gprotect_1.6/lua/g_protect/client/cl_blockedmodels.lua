-- "addons\\gms_gprotect_1.6\\lua\\g_protect\\client\\cl_blockedmodels.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()