-- "addons\\gms_gprotect_1.6\\lua\\g_protect\\languages\\sh_english.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()