-- "addons\\gms_zeros_methlab02_1.2\\lua\\autorun\\zmlab2_load.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()