-- "addons\\gms_zeros_methlab02_1.2\\lua\\entities\\zmlab2_item_autobreaker\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()