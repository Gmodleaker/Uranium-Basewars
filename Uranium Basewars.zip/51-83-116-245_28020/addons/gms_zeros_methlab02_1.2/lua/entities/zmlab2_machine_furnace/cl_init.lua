-- "addons\\gms_zeros_methlab02_1.2\\lua\\entities\\zmlab2_machine_furnace\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()