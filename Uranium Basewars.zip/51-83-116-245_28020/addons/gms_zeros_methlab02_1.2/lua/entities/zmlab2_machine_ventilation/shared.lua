-- "addons\\gms_zeros_methlab02_1.2\\lua\\entities\\zmlab2_machine_ventilation\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()