-- "addons\\gms_zeros_methlab02_1.2\\lua\\entities\\zmlab2_storage\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()