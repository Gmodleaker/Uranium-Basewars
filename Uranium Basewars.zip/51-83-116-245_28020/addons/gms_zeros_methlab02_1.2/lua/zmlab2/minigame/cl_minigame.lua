-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\minigame\\cl_minigame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()