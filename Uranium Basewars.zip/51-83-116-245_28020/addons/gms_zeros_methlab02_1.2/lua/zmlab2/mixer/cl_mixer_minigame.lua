-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\mixer\\cl_mixer_minigame.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()