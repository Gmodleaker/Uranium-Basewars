-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\pollutionsystem\\cl_pollutionsystem.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()