-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\sh_storage_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()