-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\util\\cl_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()