-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\util\\sh_convar.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()