-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2\\util\\sh_materials.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()