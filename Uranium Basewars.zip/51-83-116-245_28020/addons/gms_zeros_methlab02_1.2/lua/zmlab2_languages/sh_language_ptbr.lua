-- "addons\\gms_zeros_methlab02_1.2\\lua\\zmlab2_languages\\sh_language_ptbr.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()