-- "addons\\lean-prod\\lua\\autorun\\load_lean.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()