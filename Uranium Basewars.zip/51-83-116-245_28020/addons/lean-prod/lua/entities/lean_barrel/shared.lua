-- "addons\\lean-prod\\lua\\entities\\lean_barrel\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()