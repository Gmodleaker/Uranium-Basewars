-- "addons\\lean-prod\\lua\\entities\\lean_crate\\shared.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()