-- "addons\\lean-prod\\lua\\entities\\lean_smallcrate\\cl_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()