-- "addons\\lean-prod\\lua\\lean_config.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()