-- "addons\\lean-prod\\lua\\lean_production\\cl_fonts.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()