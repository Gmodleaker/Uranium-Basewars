-- "addons\\lean-prod\\lua\\lean_production\\cl_leanigcfg.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()