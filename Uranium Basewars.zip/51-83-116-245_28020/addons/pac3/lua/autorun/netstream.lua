-- "addons\\pac3\\lua\\autorun\\netstream.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()