-- "addons\\pac3\\lua\\autorun\\pac_extra_init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()