-- "addons\\pac3\\lua\\autorun\\pac_version.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()