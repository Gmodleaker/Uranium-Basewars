-- "addons\\pac3\\lua\\pac3\\core\\client\\base_movable.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()