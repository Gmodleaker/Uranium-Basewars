-- "addons\\pac3\\lua\\pac3\\core\\client\\base_part.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()