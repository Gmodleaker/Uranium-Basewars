-- "addons\\pac3\\lua\\pac3\\core\\client\\hooks.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()