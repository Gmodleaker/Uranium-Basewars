-- "addons\\pac3\\lua\\pac3\\core\\client\\init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()