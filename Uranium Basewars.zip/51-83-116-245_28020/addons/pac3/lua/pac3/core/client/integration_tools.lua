-- "addons\\pac3\\lua\\pac3\\core\\client\\integration_tools.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()