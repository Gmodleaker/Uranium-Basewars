-- "addons\\pac3\\lua\\pac3\\core\\client\\owner_name.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()