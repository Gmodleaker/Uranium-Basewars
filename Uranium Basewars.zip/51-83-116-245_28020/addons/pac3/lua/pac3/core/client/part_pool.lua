-- "addons\\pac3\\lua\\pac3\\core\\client\\part_pool.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()