-- "addons\\pac3\\lua\\pac3\\core\\client\\parts\\halo.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()