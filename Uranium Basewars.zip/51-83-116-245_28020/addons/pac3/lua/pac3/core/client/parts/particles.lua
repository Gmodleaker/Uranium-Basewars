-- "addons\\pac3\\lua\\pac3\\core\\client\\parts\\particles.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()