-- "addons\\pac3\\lua\\pac3\\core\\shared\\entity_mutator.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()