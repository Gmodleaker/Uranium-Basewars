-- "addons\\pac3\\lua\\pac3\\core\\shared\\entity_mutators\\blood_color.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()