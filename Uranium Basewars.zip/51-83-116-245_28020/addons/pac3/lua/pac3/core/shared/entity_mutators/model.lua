-- "addons\\pac3\\lua\\pac3\\core\\shared\\entity_mutators\\model.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()