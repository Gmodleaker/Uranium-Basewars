-- "addons\\pac3\\lua\\pac3\\core\\shared\\entity_mutators\\size.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()