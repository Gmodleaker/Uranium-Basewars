-- "addons\\pac3\\lua\\pac3\\core\\shared\\footsteps_fix.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()