-- "addons\\pac3\\lua\\pac3\\core\\shared\\util.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()