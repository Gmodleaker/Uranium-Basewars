-- "addons\\pac3\\lua\\pac3\\editor\\client\\language.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()