-- "addons\\pac3\\lua\\pac3\\editor\\client\\panels\\extra_properties.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()