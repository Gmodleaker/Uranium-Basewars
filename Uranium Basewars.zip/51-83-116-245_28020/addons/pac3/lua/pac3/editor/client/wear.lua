-- "addons\\pac3\\lua\\pac3\\editor\\client\\wear.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()