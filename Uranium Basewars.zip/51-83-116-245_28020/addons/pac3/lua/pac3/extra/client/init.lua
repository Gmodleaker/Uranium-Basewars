-- "addons\\pac3\\lua\\pac3\\extra\\client\\init.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()