-- "addons\\pac3\\lua\\pac3\\extra\\client\\pac2_compat.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()