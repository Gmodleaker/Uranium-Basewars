-- "addons\\pac3\\lua\\pac3\\extra\\client\\wire_expression_extension.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()