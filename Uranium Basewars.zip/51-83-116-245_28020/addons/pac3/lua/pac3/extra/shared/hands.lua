-- "addons\\pac3\\lua\\pac3\\extra\\shared\\hands.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()