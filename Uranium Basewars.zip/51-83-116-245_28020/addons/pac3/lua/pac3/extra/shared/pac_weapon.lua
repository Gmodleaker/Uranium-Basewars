-- "addons\\pac3\\lua\\pac3\\extra\\shared\\pac_weapon.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()