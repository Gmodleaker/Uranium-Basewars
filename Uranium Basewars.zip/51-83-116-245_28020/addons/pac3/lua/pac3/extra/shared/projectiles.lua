-- "addons\\pac3\\lua\\pac3\\extra\\shared\\projectiles.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()