-- "addons\\pac3\\lua\\pac3\\libraries\\expression.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()