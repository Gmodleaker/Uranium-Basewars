-- "addons\\pac3\\lua\\pac3\\libraries\\urlobj\\cache.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()