-- "addons\\pac3\\lua\\pac3\\libraries\\urlobj\\queueitem.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()