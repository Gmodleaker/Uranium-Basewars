-- "addons\\pac3\\lua\\pac3\\libraries\\urltex.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()