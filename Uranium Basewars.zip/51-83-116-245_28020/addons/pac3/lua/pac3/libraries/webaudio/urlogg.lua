-- "addons\\pac3\\lua\\pac3\\libraries\\webaudio\\urlogg.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()