-- "addons\\permaprops\\lua\\autorun\\client\\cl_permaload.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()