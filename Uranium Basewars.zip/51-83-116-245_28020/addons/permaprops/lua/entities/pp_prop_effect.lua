-- "addons\\permaprops\\lua\\entities\\pp_prop_effect.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()