-- "addons\\permaprops\\lua\\permaprops\\cl_drawent.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()