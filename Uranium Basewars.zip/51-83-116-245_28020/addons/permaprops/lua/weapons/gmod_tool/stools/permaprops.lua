-- "addons\\permaprops\\lua\\weapons\\gmod_tool\\stools\\permaprops.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()