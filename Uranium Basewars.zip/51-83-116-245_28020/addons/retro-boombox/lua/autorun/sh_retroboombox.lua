-- "addons\\retro-boombox\\lua\\autorun\\sh_retroboombox.lua"
-- Retrieved by https://github.com/lewisclark/glua-steal
return gluapack()()